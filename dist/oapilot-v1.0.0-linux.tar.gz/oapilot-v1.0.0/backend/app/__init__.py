"""OAPilot - Offline AI Pilot System"""

__version__ = "1.0.0"